/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphicaldiagram;

/**
 *
 * @author lehmia.kiran
 */
public class Line extends GraphicalElement{

    public Line(String ID) {
        this.ID=ID;
    }

    @Override
    protected double area() {
        area=1;
      return area;//To change body of generated methods, choose Tools | Templates.
    }

    
   
    
}
