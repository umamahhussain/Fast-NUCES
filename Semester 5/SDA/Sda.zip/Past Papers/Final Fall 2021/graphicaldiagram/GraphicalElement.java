/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphicaldiagram;

/**
 *
 * @author lehmia.kiran
 */
public abstract class GraphicalElement {
    protected String ID;
    protected double area;
    protected abstract double area();
    
    
}
